/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sort;

/**
 *
 * @author DR Eminem
 */
public class mergeSort {

    // Implementation of the merge sort algorithm
    public static int[] mergeSorting(int[] arr) {
        // Shows the initial unsorted array
        System.out.print("Current Array: ");
        printArray(arr);

        // Base case: if array has 1 or 0 elements, it's already sorted
        if (arr.length <= 1) {
            return arr;
        }

        // Find the middle index to divide the array into two halves
        int mid = arr.length / 2;

        // Creating left and right subarrays
        int[] leftHalf = new int[mid];
        int[] rightHalf = new int[arr.length - mid];

        // Copying elements from original array to the subarrays
        System.arraycopy(arr, 0, leftHalf, 0, mid);
        System.arraycopy(arr, mid, rightHalf, 0, arr.length - mid);

        System.out.println("Dividing array into two halves:");
        System.out.print("Left Half: ");
        printArray(leftHalf);
        System.out.print("Right Half: ");
        printArray(rightHalf);

        // Recursively sorting left and right subarrays
        leftHalf = mergeSorting(leftHalf);
        rightHalf = mergeSorting(rightHalf);

        // Merge the sorted subarrays
        int[] mergedArray = merge(leftHalf, rightHalf);

        System.out.println("Merging left and right halves:");
        System.out.print("Merged Array: ");
        printArray(mergedArray);

        return mergedArray;
    }

    // Method to merge the left and right subarrays
    public static int[] merge(int[] left, int[] right) {
        System.out.println("Merging process between Left and Right:");

        // Create merged array with size equal to left + right
        int[] merged = new int[left.length + right.length];

        // Initialize indices for left, right, and merged arrays
        int leftIndex = 0, rightIndex = 0, mergeIndex = 0;

        // Merge smaller elements first
        while (leftIndex < left.length && rightIndex < right.length) {
            if (left[leftIndex] <= right[rightIndex]) {
                merged[mergeIndex++] = left[leftIndex++];
            } else {
                merged[mergeIndex++] = right[rightIndex++];
            }
        }

        // Copy remaining elements from left array
        while (leftIndex < left.length) {
            merged[mergeIndex++] = left[leftIndex++];
        }

        // Copy remaining elements from right array
        while (rightIndex < right.length) {
            merged[mergeIndex++] = right[rightIndex++];
        }

        System.out.println("After merging: ");
        printArray(merged);

        return merged;
    }

    // Utility method to print an array
    public static void printArray(int[] array) {
        System.out.print("{ ");
        for (int i : array) {
            System.out.print(i + " ");
        }
        System.out.println("}");
    }

   
}

   